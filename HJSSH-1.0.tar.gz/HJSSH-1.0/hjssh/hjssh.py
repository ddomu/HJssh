#!/usr/bin/python
#------------------------------------------------------------------------------
# file name : hjssh.py  
#	
# ARGS 		: ip <str>,  commands <list> 
# RETURN  	: hostname<str>, command result <dict>, Error<str>  
#
# Created on 2015/11/28 by HJ park <hpark84@jhu.edu> 
#-----------------------------------------------------------------------------
from ssh_lib import *

def conn(ip,command_list):
	try:
		#Define SSH parameters		
		session = paramiko.SSHClient()
		session.set_missing_host_key_policy(paramiko.AutoAddPolicy())
		#Passing the necessary parameters
		#session.connect(ip, username = username, password = password, timeout=TIMEOUT , look_for_keys = False)
		session.connect(ip, username = username, password = password, timeout=TIMEOUT , look_for_keys = False, allow_agent=False, auth_timeout=TIMEOUT, banner_timeout = TIMEOUT )

	except paramiko.AuthenticationException:
		Error =  ip + ": * Invalid username or password.* Please check the username/password"
		return (ip, "", Error)
        
	except paramiko.ChannelException:
		Error =  ip + ": Failed to open new channel"
		return (ip,"", Error)

	except paramiko.ssh_exception.NoValidConnectionsError:
		Error =  "NoValidConnection to this device :"+ ip
		# Error 
		return (ip,"", Error)
	except :
		Error = ip + " : SSH Connection Time Out"
		return (ip, "", Error)

	try:
		# Start an interactive shell session on the router
		connection = session.invoke_shell()	
		connection.settimeout(TIMEOUT)
        
		output = connection.recv(MAX_BUF)
		time.sleep(PAUSE)
		# User mode to enable 
		if ">" in list(output)[-5:] :
			if not(connection.send(ENABLE +"\n")): 
				raise RuntimeError("Connection Failed during enable")
			else : 
				output = connection.recv(MAX_BUF)
				if 'Invalid' in output: pass 
				else : connection.send(password + '\n')
				
		# Wait for the command completed 
		while not ("#" in list(output)[-10:]):  	#	 MTWDAVDC2N7KAGG1-Layer2#
			time.sleep(PAUSE)
			try: 
				output = connection.recv(MAX_BUF)
				if "UCS" in output: 				# UCS needs connect nxos 
					try:
						connection.send("connect nxos\n")
					except: 
						Error += "Connect NXOS error "
						return (ip, "", Error)
			except: 		#	Raises socket.timeout:
				Error =  "SSH connection TIMEOUT to get hostname"
				return (ip,"", Error)		
		
		last_line = output.splitlines()[-1] 		# last_line = Hostname#
		host_name = last_line.replace("#","").replace('\r','').replace(' ','')

		#	Setting terminal length for entire output - no pagination
		if not connection.send(TERM_LEN +"\n"):
			raise RuntimeError("Connection Failed during TERM length")
		#	Wait for the command completed	
		else:
			while not(TERM_LEN in output and "#" in list(output)[-10:]): 
				time.sleep(PAUSE)
				output += connection.recv(MAX_BUF)

		# Send command 
		result_list = {}
		for cmd in command_list: 
			output = ""     # for each channel.recv 
			Error  = ""
			if not connection.send (cmd +'\n'): 
				E = cmd+"Connection Failed as sending command" + cmd
				raise RuntimeError(E)
				return (host_name, output, E) 
			else : 
				# receive the output from buffer 
				while not (cmd in output): 
					time.sleep(PAUSE) 
					output += connection.recv(MAX_BUF)
				# Need to gobble up any remaining output after program terminates...
				cmd_line = output.splitlines()[-1] 

				# Wait for prompt
				while not (host_name in cmd_line  and "#" in cmd_line[-2:] ):	
					try: 
						output += connection.recv(MAX_BUF)
						cmd_line = output.splitlines()[-1] 
						time.sleep(PAUSE)
					except: 
						Error +=  "SSH connection TIMEOUT "
						return (host_name,output, Error)	
					
			#result_list[cmd] = output.replace(last_line,'').replace('\r','')
			last_line = output.splitlines()[-1]
			result_list[cmd] = output.replace(last_line,'').replace(cmd,'').replace('\r','')
			result_list[cmd] = result_list[cmd][1:-1]
		#Closing the connection
		session.close()
		return host_name, result_list , Error
		
	except:
		Error =  "SSH connection failed Unknown reason"
		return (host_name,"", Error)
		
		
# -- main() --- #
if __name__ == '__main__' : 
	if len(sys.argv)  >  2: 
	# Usage : "python hjssh_.py 10.14.0.1 show ip arp , show mac addr, show vlan, "
		ip = sys.argv[1]
		cmds = sys.argv[2:]
		cmd_list = ' '.join(cmds).split(',')  # change the command as list 

		host_name, result_list, Error = conn(ip,cmd_list)
		
		print "host_name:", host_name
		if not Error : 
			for i in result_list.keys():
				print "command : ", i 
				print result_list[i]
		else: 
			print Error 
	# Usage :	
	else : 
		print "hjssh.py  <device ip > <command 1>, <command2 >, <command3> " 
 
