#!/usr/bin/python
#-----------------------------------------------------------------------------
import os,sys
import paramiko,socket		#ssh connection 
import re				#regular expression
import time				#time 
MAX_BUF = 65530			# channel receive buffer size max 
PAUSE = 1.5		# time sleep 
TIMEOUT =  5.0
ENABLE = "enable" 
TERM_LEN = "terminal length 0 " 
 
username = "username"
password = "password"

