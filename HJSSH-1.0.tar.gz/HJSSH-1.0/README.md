# How to Install 

# How to use

* Command format
> hjssh.py  device ip  command 1, command2 , command3 

* Example 
> hjssh_.py 10.10.10.10 show run, show ip arp , show mac addr, show vlan


Prepared by : HJ park hpark84@jhu.edu