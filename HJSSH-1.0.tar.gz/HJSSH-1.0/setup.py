from setuptools import setup, find_packages


setup(
    name             = 'HJSSH',
    version          = '1.0',
    description      = 'SSH to cisco devices running multiple commands with Paramiko',
    long_description = open('README.md').read(),
    author           = 'HJ Park',
    author_email     = 'hpark84@jhu.edu',
    url              = 'https://...',
    download_url     = 'https://...',
    install_requires = [
        'paramiko==2.4.2',
    ],
    packages         = find_packages(exclude = ['docs', 'example']),
    keywords         = ['cisco', 'nxos', 'ios', 'ucs'],
    python_requires  = '>=2.7',
    zip_safe=False,
    classifiers      = [
        'Programming Language :: Python :: 2.7',
    ]
)